package com.jinger;

/**
 * keche
 * @author 0018559519
 *
 */
public class PassageCar extends Car {
	public PassageCar(String name, int people, int rent) {
		this.setName(name);
		this.setPeople(people);
		this.setRent(rent);

	}

	public String toString() {
		return this.getName() + "\t" + this.getPeople() + "\t\t\t\t"
				+ this.getRent();
	}
}
