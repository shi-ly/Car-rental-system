package com.jinger;

import java.util.Scanner;

public class Initial {
	public static void main(String[] args) {
		// get Instances of cars
		Car[] cars = {
				new PassageCar("Audio A4", 4, 500),
				new PassageCar("Mazda 6", 4, 400),
				new Pickup("Pickup Snow 6", 4, 2, 450),
				new PassageCar("JinLong", 20, 800),
				new Truck("SongHuaJiang", 4, 400),
				new Truck("Naveco", 20, 1000) };
		System.out.println("****Welcome to CAR RENT System！****");
		System.out.println("****Would you like to rent a car?****" + "\n" + "Yes(Please input 1) \t No(Please input 2)");

		Scanner in1 = new Scanner(System.in);
		int is = in1.nextInt();
		if (is != 1) {
			System.out.println("****Bye! Welcome to come next time！****");
			System.exit(0);
		}
		if (is == 1) {
			System.out.println("****Please see the car type and the price:****");
			System.out.println("NO" + "\tCar Name" + "\tCustomer Number(Capacity)" + "\tWeight of Load(Ton)"
					+ "\tRenbt Fee(RMB/Day)");

			// print car type
			for (int i = 0; i < cars.length; i++) {
				System.out.println((i + 1) + "\t" + cars[i]);
			}

			System.out.println("****Please input how many car would you like to rent：****");
			int num1 = in1.nextInt();
			Car[] rentcar = new Car[num1];
			int price = 0;// total price
			int totalpeople = 0;// total numbers of people
			int totalloads = 0;// total weight of load

			for (int i = 0; i < num1; i++) {
				System.out.println("****Plese input the car number:" + (i + 1) + "****");
				int numx = in1.nextInt();
				rentcar[i] = cars[numx - 1];

			}
			System.out.println("****Please input how many days you would like to rent：****");
			int day = in1.nextInt();
			for (int i = 0; i < num1; i++) {
				price = price + rentcar[i].rent * day;
			}
			System.out.println("****Your Account：****");
			System.out.println("PassageCars that you have already slected：");
			for (int i = 0; i < num1; i++) {
				if (rentcar[i].people != 0) {
					System.out.println(rentcar[i].name + "\t");
				}

				totalpeople = totalpeople + rentcar[i].people;
			}

			System.out.println('\n');
			System.out.println("Pickup Trucks that you have already slected：");
			for (int i = 0; i < num1; i++) {
				if (rentcar[i].loads != 0) {
					System.out.println(rentcar[i].name + "\t");
				}

				totalloads = totalloads + rentcar[i].loads;
			}

			System.out.println('\n');
			System.out.println("total numbers of people：" + totalpeople + "people");
			System.out.println("total weights of loads：" + totalloads + "ton");
			System.out.println("total price：" + price + "RMB");
			System.out.println('\n');
			System.out.println("****Thank you！ Waiting for you again!****");

		}
	}
}
