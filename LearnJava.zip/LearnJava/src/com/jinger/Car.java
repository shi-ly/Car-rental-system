package com.jinger;

/**
 * che
 * @author 0018559519
 *
 */
public abstract class Car {
	public int rent;   // zujin/day
	public int people; // keren shu
	public int loads;  // zaike liang
	public String name;// car name

	public int getRent() {
		return rent;
	}

	public void setRent(int rent) {
		this.rent = rent;
	}

	public int getPeople() {
		return people;
	}

	public void setPeople(int people) {
		this.people = people;
	}

	public int getLoads() {
		return loads;
	}

	public void setLoads(int loads) {
		this.loads = loads;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
