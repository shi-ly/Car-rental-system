package com.jinger;

public class Truck extends Car {
	public Truck(String name,int loads,int rent){
		this.setName(name);
		this.setLoads(loads);
		this.setRent(rent);
	}
	
	public String toString(){
		return this.getName()+"\t\t\t"+this.getLoads()+"\t\t"+this.getRent();
	}
	}



