package com.jinger;

public class Pickup extends Car {
	public Pickup(String name,int people,int loads,int rent){
		this.setName(name);
		this.setPeople(people);
		this.setLoads(loads);
		this.setRent(rent);
	}
	
	public String toString(){
		return this.getName()+"\t"+this.getPeople()+"\t\t"+this.getLoads()+"\t\t"+this.getRent();
	}
	}
	