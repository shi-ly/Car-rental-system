package com.jinger;

public class Pickup extends Car {
	private String name;
	private int people;
	private int rent;	
	private int loads;

	public Pickup(String name,int rent,int loads,int people){
		this.name=name;
		this.rent=rent;
		this.loads=loads;
		this.people=people;
	}
	
	public String getName(){
		return name;
	}
	public void setName(String name){
		this.name=name;
	}
	public int getRent(){
		return rent;
	}
	public void setRent(){
		this.rent=rent;
	}
	public int getLoads(){
		return loads;
	}
	public void setLoads(){
		this.loads=loads;
	}
	public int getPeople(){
		return people;
	}
	public void setPeople(int people){
		this.people=people;
	}
}
