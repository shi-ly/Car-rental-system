package com.jinger;

public abstract class Car {
	public int rent;
	public int people;
	public int loads;
	public String name;
	
	public int getRent(){
		return rent;
	}
	public void setRent(int rent){
		this.rent=rent;
	}
	public int getPeople(){
		return people;
	}
	public void setPeople(int people){
		this.people=people;
	}
	public int getLoads(){
		return loads;
	}
	public void setLoads(int loads){
		this.loads=loads;
	}
	
	public String getName(){
		return name;
	}
	public void setName(String name){
		this.name=name;
	}
}

