package com.jinger;

public class Truck extends Car {
	private String name;
	private int rent;
	private int loads;

public Truck(String name,int rent,int loads){
	this.name=name;
	this.rent=rent;
	this.loads=loads;
}

public String getName(){
	return name;
	}
public void setName(String name){
	this.name=name;
}
public int getRent(){
	return rent;
}
public void setRent(int rent){
	this.rent=rent;
}
public int getLoads(){
	return loads;
}
public void setLoads(){
	this.loads=loads;
}
}

