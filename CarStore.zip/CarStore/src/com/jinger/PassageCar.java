package com.jinger;

public class PassageCar extends Car{
	private int rent;
	private int people;
	private String name;
	
	public PassageCar(String name,int people,int rent){
		this.name=name;
		this.people=people;
		this.rent=rent;
	}
	
	public int getRent(){
		return rent;
	}
	public void setRent(int rent){
		this.rent=rent;
	}
	public String getName(){
		return name;
	}
	public void setName(String name){
		this.name=name;
	}
	public int getPeople(){
		return people;
	}
	public void setPeople(int people){
		this.people=people;
	}
}
